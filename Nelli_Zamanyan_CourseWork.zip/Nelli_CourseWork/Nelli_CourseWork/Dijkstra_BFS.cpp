#include "pch.h"
#include "Dijkstra_BFS.h"
#include <iostream>
#include <fstream>
#include <queue>
#include <set>

#define INF 1000    // INFINITY

void Graph::addDijkstraNeighbor()    // addEdge Method implementation
{
	std::ifstream input("Dijkstra.txt");
	input >> number_of_vertices;
	input >> number_of_edges;
	int vertex_1;
	int vertex_2;
	int weight;
	DijkstrasadjacencyList.resize(number_of_vertices);
	for (int i = 0; i < number_of_edges; i++)
	{
		input >> vertex_1;
		input >> vertex_2;
		input >> weight;
		DijkstrasadjacencyList[vertex_1].push_back(std::make_pair(vertex_2, weight));
		DijkstrasadjacencyList[vertex_2].push_back(std::make_pair(vertex_1, weight));
	}
}

void Graph::addBFSNeighbor()
{
	std::ifstream input("BFS.txt");
	input >> number_of_vertices;
	input >> number_of_edges;
	int vertex_1;
	int vertex_2;
	BFSadjacencyList.resize(number_of_vertices);
	for (int i = 0; i < number_of_edges; i++)
	{
		input >> vertex_1;
		input >> vertex_2;
		BFSadjacencyList[vertex_1].push_back(vertex_2);
		BFSadjacencyList[vertex_2].push_back(vertex_1);
	}
}

void Graph::printDijkstrasAdjacencyList()    // printGraph Method implementation
{
	std::cout << " There are " << number_of_vertices << " Vertices in the Graph\n\n";
	std::cout << " *** List of Vertices ***" << "                 *** adjacencyListacencies ***\n";
	for (int v = 0; v < number_of_vertices; ++v)
	{
		std::cout << "\n adjacencyListacency list of Vertex " << v << ":   ";
		for (auto i = DijkstrasadjacencyList[v].begin(); i != DijkstrasadjacencyList[v].end(); ++i)
		{
			std::cout << "  " << (*i).first;     // Print the adjacencyListacent vertex
		}
	}
	std::cout << "\n\n";
}

void Graph::printBFSAdjacencyList()
{
	std::cout << " *** Adjacencey List *** \n";
	for (int i = 0; i < BFSadjacencyList.size(); ++i)
	{
		std::cout << " " << i;
		for (int j = 0; j < BFSadjacencyList[i].size(); ++j)
		{
			std::cout << "  " << BFSadjacencyList[i][j];
		}
		std::cout << '\n';
	}
	std::cout << '\n';
}

void Graph::DijkstrasShortestPath(int vertex)    // Implementation of method shortestPath where 'vertex' is the initial point
{
	std::set<std::pair<int, int>> mySet;    // A set to keep vertices and their distances
	std::vector<int> distances(number_of_vertices, INF);    // Vector for distances. All paths are initialized to a large value

	mySet.insert(std::make_pair(0, vertex)); // 0 is the distance and s is the initial point 
	distances[vertex] = 0; // Initializes distance to 0

	while (!mySet.empty())  // Continue until all shortest distances are finalized
	{
		std::pair<int, int> tmp = *(mySet.begin()); // Extract the minimum distances
		mySet.erase(mySet.begin());
		for (auto i = DijkstrasadjacencyList[tmp.second].begin(); i != DijkstrasadjacencyList[tmp.second].end(); ++i) // Goes over the adjacencyListacency list
		{
			if (tmp.first + (*i).second < distances[(*i).first]) // Checks if we found a shorter path to v
			{
				if (distances[(*i).first] != INF) // Checks if the value of distance of v is not INFINITY
				{
					mySet.erase(std::make_pair(distances[(*i).first], (*i).first));
				}
				distances[(*i).first] = tmp.first + (*i).second;
				mySet.insert(std::make_pair(distances[(*i).first], (*i).first));
			}
		}
	}
	std::cout << " Minimum Distances from vertex " << vertex << '\n';
	for (int i = 0; i < number_of_vertices; ++i)
	{
		std::cout << " {" << vertex << "} --> " << "{" << i << "}: " << distances[i] << '\n';
	}
	std::cout << '\n';
}

void Graph::BFSShortestPath(int startVertex)
{
	int v = startVertex;
	std::queue<int> myQueue;
	std::vector<int> distances(number_of_vertices, -1);
	int q = 0;
	myQueue.push(startVertex);
	distances[startVertex] = q;
	while (!myQueue.empty())
	{
		for (int i = 0; i < BFSadjacencyList[startVertex].size(); ++i)
		{	
			q = distances[startVertex] + 1;
			if (distances[BFSadjacencyList[startVertex][i]] == -1)
			{
				myQueue.push(BFSadjacencyList[startVertex][i]);
				distances[BFSadjacencyList[startVertex][i]] = q;
			}
		}
		myQueue.pop();
		if (!myQueue.empty())
		{
			startVertex = myQueue.front();
		}
	}
	for (int i = 0; i < distances.size(); ++i)
	{
		if (i < 10)
		{
			std::cout << " From {" << v << "} to {" << i << "}  The Minimum Distance Is: " << distances[i] << '\n';
		}
		else
		{
			std::cout << " From {" << v << "} to {" << i << "} The Minimum Distance Is: " << distances[i] << '\n';
		}
	}
}