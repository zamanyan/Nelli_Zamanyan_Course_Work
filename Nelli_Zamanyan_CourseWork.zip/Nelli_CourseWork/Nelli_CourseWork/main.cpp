#include "pch.h"
#include "Dijkstra_BFS.h"
#include <iostream>

int main()
{
	std::cout << " Enter 0 --> weigted:\n       1 --> unweighted: ";
	int n;
	std::cin >> n;
	std::cout << std::endl;
	Graph G;
	if (n == 0)
	{
		G.addDijkstraNeighbor();
		G.printDijkstrasAdjacencyList();
		std::cout << '\n';

		for (int i = 0; i < 7; ++i)
		{
			G.DijkstrasShortestPath(i);
		}
	}
	else
	{
		G.addBFSNeighbor();
		G.printBFSAdjacencyList();

		G.BFSShortestPath(0);
	}
	return 0;
}
