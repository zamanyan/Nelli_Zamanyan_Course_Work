#pragma once
#include <vector>

class Graph
{
private:
	int number_of_vertices; // Graph's vetices number
	int number_of_edges;
	std::vector<std::vector<std::pair<int, int>>> DijkstrasadjacencyList; // Vector of vertices, its adjacencies and edge lengths
	std::vector<std::vector<int>> BFSadjacencyList;
public:
	void addDijkstraNeighbor(); // Method to add an edge/weight pair
	void addBFSNeighbor();	// Method to add neighbor
	void printDijkstrasAdjacencyList(); // Method to print vertices and its adjancency lists
	void printBFSAdjacencyList();
	void DijkstrasShortestPath(int); // Method to find the shortest paths of weighted graph by Dijkstra's algorithm
	void BFSShortestPath(int);	// Method to find shortest paths of unweighted graph by BFS algorithm
};
